package com.bookt.bakingapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

import com.bookt.bakingapp.Adapters.MenuAdapter;
import com.bookt.bakingapp.Adapters.StepAdapter;
import com.bookt.bakingapp.Classes.Recipe;

import java.util.ArrayList;


public class RecipeDetailActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    RecyclerView recyclerView;
    MenuAdapter menuAdapter;
    TextView menuHeader;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        Intent intent  =getIntent();

        ArrayList<Recipe> recipes = intent.getParcelableArrayListExtra(getString(R.string.recipe));

        recyclerView = findViewById(R.id.menu_recycler_view);
        menuHeader  = findViewById(R.id.menu_header);
        menuAdapter  = new MenuAdapter(this,recipes);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(menuAdapter);


        Recipe recipe = recipes.get(intent.getIntExtra("ID",0));
        menuHeader.setText(this.getString(R.string.recipes_header));
        this.setTitle(recipe.getName());



        if(findViewById(R.id.recipe_steps_recycler)!=null){
            RecyclerView recyclerView = findViewById(R.id.recipe_steps_recycler);
            StepAdapter stepAdapter = new StepAdapter(this,recipe.getSteps());
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            recyclerView.setAdapter(stepAdapter);
        }





    }


    @Override
    protected void onPause() {
        super.onPause();
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        return false;
    }
}
