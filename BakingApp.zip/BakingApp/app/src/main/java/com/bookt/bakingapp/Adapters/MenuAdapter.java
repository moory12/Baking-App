package com.bookt.bakingapp.Adapters;


import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


import com.bookt.bakingapp.Classes.Recipe;
import com.bookt.bakingapp.Classes.Step;
import com.bookt.bakingapp.R;
import com.bookt.bakingapp.RecipeDetailActivity;

import java.util.ArrayList;


public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MyViewHolder> {

    private Context mContext;
    private ArrayList<Recipe> mArrayList;

    public MenuAdapter(Context mContext, ArrayList<Recipe> mArrayList) {
        this.mContext = mContext;
        this.mArrayList = mArrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        view = layoutInflater.inflate(R.layout.menu_card,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, final int i) {

        myViewHolder.step.setText((i+1)+"- "+mArrayList.get(i).getName());
        myViewHolder.step.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(mContext, RecipeDetailActivity.class);
                intent.putExtra("ID",i);
                intent.putParcelableArrayListExtra(mContext.getString(R.string.recipe),mArrayList);
                mContext.startActivity(intent);
            }
        });
        myViewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(mContext, RecipeDetailActivity.class);
                intent.putExtra("ID",i);
                intent.putParcelableArrayListExtra(mContext.getString(R.string.recipe),mArrayList);
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mArrayList.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder{

        CardView cardView;
        TextView step;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            step = itemView.findViewById(R.id.step_name);
            cardView = itemView.findViewById(R.id.menu_card);
        }
    }

}
